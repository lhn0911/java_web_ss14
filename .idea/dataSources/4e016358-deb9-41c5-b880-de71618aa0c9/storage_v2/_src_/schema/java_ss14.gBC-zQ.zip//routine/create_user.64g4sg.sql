create
    definer = root@localhost procedure create_user(IN username_in varchar(50), IN password_in varchar(255),
                                                   IN email_in varchar(100))
begin
    insert into User(username, password, email)
    values (username_in, password_in, email_in);
end;

